from Bio import Entrez, SeqIO
import matplotlib.pyplot as plt

Entrez.email = "your-email@example.com"  # Required by NCBI


def find_repetitions(sequence, min_length=3, max_length=6, min_repeats=2):
    results = {}
    for pattern_length in range(min_length, max_length + 1):
        pattern_counts = {}
        for i in range(len(sequence) - pattern_length + 1):
            pattern = sequence[i:i + pattern_length]
            if all(base in 'ACGT' for base in pattern):
                pattern_counts[pattern] = pattern_counts.get(pattern, 0) + 1
        repetitive_patterns = {pattern: count for pattern, count in pattern_counts.items() if count >= min_repeats}
        if repetitive_patterns:
            results[pattern_length] = dict(sorted(repetitive_patterns.items(), key=lambda x: (-x[1], x[0])))
    return results

def plot_repetitions(results, genome_id, top_n=10):
    all_patterns = []
    all_counts = []
    for length in sorted(results.keys()):
        patterns = results[length]
        for pattern, count in list(patterns.items())[:top_n]:
            all_patterns.append(f"{pattern} ({length}bp)")
            all_counts.append(count)
    plt.figure(figsize=(10, 6))
    plt.bar(all_patterns, all_counts, color='skyblue')
    plt.xlabel("Repetitive Patterns")
    plt.ylabel("Occurrences")
    plt.title(f"Top Repetitive Patterns in Influenza Genome {genome_id}")
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.show()

def fetch_genome(accession):
    handle = Entrez.efetch(db="nuccore", id=accession, rettype="fasta", retmode="text")
    record = SeqIO.read(handle, "fasta")
    handle.close()
    return str(record.seq).upper()

def main():
    influenza_accessions = [
        "NC_007373.1", "NC_007366.1", "NC_007368.1", "NC_007371.1", "NC_007367.1",
        "NC_002017.1", "NC_002016.1", "NC_002018.1", "NC_002021.1", "NC_002020.1"
    ]  

    for acc in influenza_accessions:
        try:
            print(f"Fetching genome {acc}...")
            seq = fetch_genome(acc)
            print(f"Analyzing genome length {len(seq)} for repeat sequences...")
            results = find_repetitions(seq, min_length=3, max_length=6, min_repeats=2)
            plot_repetitions(results, acc, top_n=10)
        except Exception as e:
            print(f"Error processing {acc}: {e}")

if __name__ == "__main__":
    main()
