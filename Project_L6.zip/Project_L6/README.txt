Arhir Tudor
Paraschiv Vlad