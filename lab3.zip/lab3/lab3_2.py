import matplotlib.pyplot as plt

file_name = 'sequence.fasta'
sequence = ''
window_size = 9

with open(file_name, 'r') as f:
    for line in f:
        if not line.startswith('>'):
            sequence += line.strip()

positions = []
basic_tm_list = []
salt_tm_list = []

for i in range(len(sequence) - window_size + 1):
    
    window = sequence[i:i+window_size]
    
    a_count = window.count('A')
    t_count = window.count('T')
    g_count = window.count('G')
    c_count = window.count('C')
    
    basic_tm = (a_count + t_count) * 2 + (g_count + c_count) * 4
    
    gc_content = ((g_count + c_count) / window_size) * 100
    salt_tm = 81.5 + (0.41 * gc_content) - (500 / window_size)
    
    positions.append(i)
    basic_tm_list.append(basic_tm)
    salt_tm_list.append(salt_tm)

plt.figure(figsize=(12, 6))

plt.plot(positions, basic_tm_list, label='Basic Formula (2+4 Rule)')
plt.plot(positions, salt_tm_list, label='Salt-Adjusted Formula')

plt.title('DNA Melting Temperature Along Sequence')
plt.xlabel('Starting Position of 9-base Window')
plt.ylabel('Melting Temperature (Tm) in C')
plt.grid(True)
plt.legend()
plt.show()