This lab represents the calculation of the melting temperature for a given DNA sequence

ARHIR TUDOR-CRISTIAN
BUGA MIHAI
DANAILA GABRIEL
